# Cookie and Milk — Company Profile UMKM

**Nama:** [Isi nama mahasiswa]  
**NIM:** [Isi NIM mahasiswa]  
**Nama UMKM:** Cookie and Milk (fiktif)  
**Link website:** [Isi URL GitHub Pages setelah deploy]

## Deskripsi
Cookie and Milk adalah UMKM fiktif yang menjual lima varian cookies (coklat, matcha, red velvet, keju, original choco chips) dan tiga varian susu (coklat, stroberi, vanilla). Usaha ini bermula dari hobi owner ngemil cookies dan minum susu saat mengerjakan tugas.

## Teknologi
HTML5, CSS3, JavaScript vanilla. Desain responsif dan ilustrasi produk SVG doodle lokal.

## Struktur file
- `index.html` — Beranda
- `about.html` — Sejarah, visi & misi, struktur organisasi
- `produk.html` — Cookies dan minuman
- `kontak.html` — Informasi kontak dan form demonstrasi
- `css/style.css` — Styling dan responsivitas
- `js/script.js` — Hamburger menu, dropdown mobile, dan form demo
- `img/` — Ilustrasi SVG doodle

## Cara menjalankan di VS Code
1. Buka folder `cookie-and-milk` dengan VS Code.
2. Buka `index.html` di browser, atau gunakan ekstensi Live Server.
3. Semua halaman saling terhubung melalui navbar.

## Deploy GitHub Pages
1. Buat repository publik di GitHub, misalnya `cookie-and-milk`.
2. Upload semua file **beserta foldernya** ke root repository.
3. Buka **Settings → Pages → Build and deployment**.
4. Pilih **Deploy from a branch**, branch `main`, folder `/(root)`, lalu **Save**.
5. Setelah situs aktif, URL biasanya `https://USERNAME.github.io/cookie-and-milk/`.
6. Isi nama, NIM, dan URL hasil deploy pada README ini.

## Catatan
Informasi kontak adalah contoh fiktif. Form kontak hanya tampilan dan tidak mengirim pesan. Font Google Fonts memerlukan internet; fallback font tetap tersedia.
